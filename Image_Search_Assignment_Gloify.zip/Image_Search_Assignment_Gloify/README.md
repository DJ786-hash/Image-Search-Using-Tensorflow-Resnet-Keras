This is a Image Search Assignment made by Jasvir Suman.

Methods used in notebook:
Method 1: Using DeepImageSearch AI module.DeepImageSearch is open source module used to find similar images.
Method 2: Using Tensorflow library and Keras API . 

How to open ipynb file:

Install Jupyter Notebook if not already. Open in a browser Chrome or Firefox or Opera.
After openinig Jupyter Notebook surf through local directories and select Image_Search_Assignment_Gloify.
To run the code on your pc, select kernel -> restart & clear cell output and then execute each cell.

Requirements:
Jupyter Notebook
Python
DeepImageSearch module
Tensorflow
Keras
